//
//  ViewController.h
//  DummyApp
//
//  Created by Ram Prasad on 4/15/16.
//  Copyright © 2016 Ram Prasad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate>{
    
    IBOutlet UITableView *listTableView;
    IBOutlet UISearchBar *textSearchBar;
    NSMutableArray *listArray;
}


@end

