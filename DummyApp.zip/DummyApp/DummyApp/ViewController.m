//
//  ViewController.m
//  DummyApp
//
//  Created by Ram Prasad on 4/15/16.
//  Copyright © 2016 Ram Prasad. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
#import "MBProgressHUD.h"
@interface ViewController ()

@end

@implementation ViewController


#pragma mark - UIViewController Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    listArray = [NSMutableArray new];
    self.title = @"Search";
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    listTableView.estimatedRowHeight = 44.0;
    listTableView.rowHeight = UITableViewAutomaticDimension;
   
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark - UITableView Delegate and DataSource
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *simpleTableIdentifier = @"SimpleTableCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    [cell.textLabel setNumberOfLines:0];
    [cell.textLabel setLineBreakMode:NSLineBreakByWordWrapping];
    cell.textLabel.text = [listArray[indexPath.row] valueForKey:@"lf"];
    
    return cell;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    
    return listArray.count;
}


#pragma mark - Fetch data from server

-(void)fetchDataWithKeyword:(NSString *)keyWord{
    
    [MBProgressHUD showHUDAddedTo:[[UIApplication sharedApplication] keyWindow] animated:YES];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html",@"application/json",@"text/plain",nil];
    
    [manager GET:@"http://www.nactem.ac.uk/software/acromine/dictionary.py" parameters:@{@"sf":keyWord} progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MBProgressHUD hideAllHUDsForView:[[UIApplication sharedApplication] keyWindow] animated:YES];
        
        if ([responseObject isKindOfClass:[NSArray class]]) {
            if ([responseObject count]) {
                [listArray  addObjectsFromArray:[[responseObject objectAtIndex:0]valueForKey:@"lfs"]];
                [listTableView reloadData];
            }
            else{
                
                [self showAlert:@"No result found!"];
            }
          
        }
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         [MBProgressHUD hideAllHUDsForView:[[UIApplication sharedApplication] keyWindow] animated:YES];
        [self showAlert:@"Something went wrong, please check your internet connection."];

    }];
}


#pragma mark - UISearchBar Delegates

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    
    [searchBar resignFirstResponder];
    
    if (searchBar.text.length) {
        [listArray removeAllObjects];
        [listTableView reloadData];
        [self fetchDataWithKeyword:searchBar.text];

    }
    
}
-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    
    searchBar.text = nil;
    [searchBar resignFirstResponder];
}


#pragma mark - Show Alert Messege

-(void)showAlert:(NSString *)alertMessage{
    
    UIAlertController * alert=   [UIAlertController
                                  alertControllerWithTitle:nil
                                  message:alertMessage
                                  preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* dismiss = [UIAlertAction
                             actionWithTitle:@"Dismiss"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [alert dismissViewControllerAnimated:YES completion:nil];
                             }];
    
    [alert addAction:dismiss];
    [self presentViewController:alert animated:YES completion:nil];
  
}



@end
