//
//  AppDelegate.h
//  DummyApp
//
//  Created by Ram Prasad on 4/15/16.
//  Copyright © 2016 Ram Prasad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

